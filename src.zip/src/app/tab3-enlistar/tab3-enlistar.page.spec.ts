import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Tab3EnlistarPage } from './tab3-enlistar.page';

describe('Tab3EnlistarPage', () => {
  let component: Tab3EnlistarPage;
  let fixture: ComponentFixture<Tab3EnlistarPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(Tab3EnlistarPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
