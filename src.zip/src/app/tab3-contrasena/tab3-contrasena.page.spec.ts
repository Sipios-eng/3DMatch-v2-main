import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Tab3ContrasenaPage } from './tab3-contrasena.page';

describe('Tab3ContrasenaPage', () => {
  let component: Tab3ContrasenaPage;
  let fixture: ComponentFixture<Tab3ContrasenaPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(Tab3ContrasenaPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
