// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig : {
    apiKey: "AIzaSyBbGPqXmsf8p_Zuglcl3wlcAM6fV-h-P7M",
    authDomain: "dmatch-78338.firebaseapp.com",
    projectId: "dmatch-78338",
    storageBucket: "dmatch-78338.appspot.com",
    messagingSenderId: "812604593084",
    appId: "1:812604593084:web:0630370ece077dd24b11b9"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
